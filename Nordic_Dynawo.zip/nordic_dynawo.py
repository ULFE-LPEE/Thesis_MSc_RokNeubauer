from pathlib import Path
import argparse
import csv
import json
import os
import shutil
import subprocess
import sys
import time
import uuid
import xml.etree.ElementTree as ET
import numpy as np
import matplotlib.pyplot as plt

BASE = Path(__file__).resolve().parent
NS = "http://www.rte-france.com/dynawo"
GENERATORS = [6, 7, 11, 12, 14, 15, 16]
SIGNALS = ([f"U{n}" for n in [1041, 1042, 4012, 4062]] + ["Uload1"] +
           [f"m{i}" for i in range(1, 6)] + [f"IrG{g}" for g in GENERATORS] +
           ["IrLimitG12", "OelG12"] + [f"UtG{g}" for g in [6, 7]] + [f"dwG{g}" for g in [6, 7, 17]])


def find_dynawo(explicit):
    config_file = BASE / "nastavitve_zagona.json"
    config = json.loads(config_file.read_text(encoding="utf-8-sig")) if config_file.is_file() else {}
    candidates = [explicit, config.get("dynawo_home"), os.environ.get("DYNAWO_HOME"), BASE / "Dynawo",
                  BASE / "dynawo", BASE.parent / "Dynawo", BASE.parent / "dynawo", shutil.which("dynawo.cmd")]
    exe_name = "dynawo.exe" if os.name == "nt" else "dynawo"
    for candidate in candidates:
        if not candidate:
            continue
        path = Path(candidate).expanduser().resolve()
        if path.is_file():
            path = path.parent.parent if path.parent.name == "bin" else path.parent
        if (path / "bin" / exe_name).is_file() and (path / "ddb").is_dir():
            return path
        if candidate == explicit:
            raise FileNotFoundError(f"To ni namestitev simulatorja Dynawo: {path}. Potrebna sta bin/{exe_name} in ddb/.")
    raise FileNotFoundError('Simulator Dynawo ni najden. Nastavi dynawo_home v nastavitve_zagona.json.')


def runtime_environment(home):
    env = os.environ.copy()
    env.update({"DYNAWO_INSTALL_DIR": str(home) + os.sep,
                "DYNAWO_DDB_DIR": str(home / "ddb"), "DYNAWO_DICTIONARIES": "dictionaries_mapping",
                "DYNAWO_LOCALE": "en_GB", "DYNAWO_RESOURCES_DIR": str(home / "share") + os.sep,
                "DYNAWO_SCRIPTS_DIR": str(home / "sbin"), "DYNAWO_USE_XSD_VALIDATION": "true",
                "DYNAWO_XSD_DIR": str(home / "share/xsd") + os.sep, "LIBIIDM_HOME": str(home),
                "IIDM_XML_XSD_PATH": str(home / "share/iidm/xsd") + os.sep,
                "DYNAWO_LIBIIDM_EXTENSIONS": str(home / "bin"),
                "DYNAWO_PYTHON_COMMAND": sys.executable,
                "OPENMODELICA_HOME": str(home / "OpenModelica"),
                "OPENMODELICAHOME": str(home / "OpenModelica")})
    env["PATH"] = os.pathsep.join(str(home / d) for d in ["bin", "ddb", "lib", "OpenModelica/bin"]) + os.pathsep + env.get("PATH", "")
    return env


def read_csv(path):
    with path.open(encoding="utf-8-sig", newline="") as handle:
        first = handle.readline(); handle.seek(0)
        reader = csv.reader(handle, delimiter=";" if ";" in first else ",")
        header = next(reader)
        indices = [i for i, name in enumerate(header) if name.strip()]
        names = [header[i].strip() for i in indices]
        rows = [[float(row[i]) for i in indices] for row in reader if any(row)]
    values = np.asarray(rows, dtype=float)
    if values.ndim != 2 or len(values) < 2 or not np.all(np.isfinite(values)):
        raise RuntimeError(f"CSV nima dovolj veljavnih izračunanih vzorcev: {path}")
    data = dict(zip(names, values.T))
    if "time" not in data or np.any(np.diff(data["time"]) < 0):
        raise RuntimeError("Nepravilna časovna os CSV.")
    return data


def convert_curves(raw, model_dir):
    def curve(model, variable):
        key = model + "_" + variable
        if key not in raw:
            raise KeyError(f"V native Dynawo CSV manjka {key}. Preveri dnevnik in različico Dynawo.")
        return raw[key]
    data = {"time": raw["time"]}
    for node in [1041, 1042, 4012, 4062]:
        data[f"U{node}"] = curve("NETWORK", f"{node}_{131 if node<2000 else 401}_Upu_value")
    data["Uload1"] = curve("NETWORK", "B01___21_Upu_value")
    network = ET.parse(model_dir / "Nordic.xiidm")
    for i in range(1, 6):
        transformer = next(e for e in network.iter() if e.tag.endswith("}twoWindingsTransformer") and e.attrib.get("id") == f"Tr{i}-{1040+i}")
        tap_changer = next(e for e in transformer if e.tag.endswith("}ratioTapChanger"))
        low = int(tap_changer.attrib["lowTapPosition"])
        rho = np.array([float(e.attrib["rho"]) for e in tap_changer if e.tag.endswith("}step")])
        taps = curve("NETWORK", f"Tr{i}-{1040+i}_step_value")
        indices = np.rint(taps).astype(int) - low
        if np.any(np.abs(taps-np.rint(taps)) > 1e-6) or np.any(indices < 0) or np.any(indices >= len(rho)):
            raise RuntimeError(f"Neveljavne pozicije odcepov transformatorja Tr{i}-{1040+i}.")
   
        data[f"m{i}"] = 1.0 / rho[indices]
    for g in GENERATORS:
        data[f"IrG{g}"] = curve(f"g{g:02d}", "voltageRegulator_IrPu")
    params = ET.parse(model_dir / "Nordic.par")
    g12 = next(e for e in params.iter() if e.tag.endswith("}set") and e.attrib.get("id") == "Nordicg12")
    limit = next(float(e.attrib["value"]) for e in g12 if e.attrib.get("name") == "voltageRegulator_IrLimPu")
    data["IrLimitG12"] = np.full(raw["time"].size, limit)
  
    data["OelG12"] = (curve("g12", "voltageRegulator_greaterEqualThreshold_y") > 0).astype(float)
    for g in [6, 7]:
        data[f"UtG{g}"] = curve(f"g{g:02d}", "generator_UPu")
    for g in [6, 7, 17]:
        data[f"dwG{g}"] = curve(f"g{g:02d}", "generator_omegaPu_value") - 1.0
    return data


def simulate(args, out):
    home = find_dynawo(args.dynawo)
    source = BASE / "model"
    run = out / "runs" / uuid.uuid4().hex[:8]
    run.mkdir(parents=True)
    for path in source.iterdir():
        if path.is_file():
            shutil.copy2(path, run / path.name)
    ET.register_namespace("", NS)
    jobs_path = run / "Nordic.jobs"
    jobs = ET.parse(jobs_path)
    jobs.find(f".//{{{NS}}}simulation").set("stopTime", str(args.stop))
    if args.solver == "ida":
        solver = jobs.find(f".//{{{NS}}}solver")
        solver.set("lib", "dynawo_SolverIDA")
        solver.set("parFile", "SolverIDA.par")
        parameters = ET.Element(f"{{{NS}}}parametersSet")
        param_set = ET.SubElement(parameters, f"{{{NS}}}set", id="Solver")
        for name, value, kind in [("order", 2, "INT"), ("initStep", 1e-6, "DOUBLE"),
                                  ("minStep", 1e-8, "DOUBLE"), ("maxStep", args.step, "DOUBLE"),
                                  ("absAccuracy", args.tolerance, "DOUBLE"), ("relAccuracy", args.tolerance, "DOUBLE")]:
            ET.SubElement(param_set, f"{{{NS}}}par", type=kind, name=name, value=str(value))
        ET.ElementTree(parameters).write(run / "SolverIDA.par", encoding="utf-8", xml_declaration=True)
    
    outputs = jobs.find(f".//{{{NS}}}outputs")
    for child in list(outputs):
        if child.tag.endswith("}finalState"):
            outputs.remove(child)
    jobs.write(jobs_path, encoding="utf-8", xml_declaration=True)
    executable = home / "bin" / ("dynawo.exe" if os.name == "nt" else "dynawo")
    print("Zagon native Dynawo Nordic ... Dnevnik: " + str(run / "zagon.log"), flush=True)
    started = time.perf_counter()
    with (run / "zagon.log").open("w", encoding="utf-8") as handle:
        result = subprocess.run([str(executable), str(jobs_path)], cwd=run,
                                env=runtime_environment(home), stdout=handle, stderr=subprocess.STDOUT)
    seconds = time.perf_counter() - started
    raw_path = run / "outputs/curves/curves.csv"
    if not raw_path.is_file():
        raise RuntimeError(f"Dynawo ni ustvaril CSV (koda {result.returncode}). Glej {run / 'zagon.log'}.")
    try:
        data = convert_curves(read_csv(raw_path), run)
    except (RuntimeError, ValueError, KeyError) as error:
        raise RuntimeError(f"Rezultati niso veljavni (koda {result.returncode}). {error} Dnevnik: {run / 'zagon.log'}") from error
    names = ["time"] + SIGNALS
    target = out / "nordic_dynawo.csv"
    np.savetxt(target, np.column_stack([data[n] for n in names]), delimiter=";", header=";".join(names), comments="", fmt="%.12g")
    meta = {"runtime": "native Dynawo", "case": "DynaWaltz/Nordic", "solver": "dynawo_SolverIDA" if args.solver=="ida" else "dynawo_SolverSIM",
            "max_step": args.step if args.solver=="ida" else 2.0, "accuracy": args.tolerance if args.solver=="ida" else "Solver.par",
            "requested_stop": args.stop, "last_time": float(data["time"][-1]), "simulation_seconds": seconds,
            "returncode": result.returncode, "partial": bool(result.returncode != 0 or data["time"][-1] < args.stop - 1e-5),
            "run": str(run), "dynawo_home": str(home)}
    (out / "nastavitve.json").write_text(json.dumps(meta, indent=2), encoding="utf-8")
    print(f"CSV shranjen: {target}", flush=True)
    if meta["partial"]:
        print(f"Zagon ni dokončan. Zadnji izračunani čas: {data['time'][-1]:.6f} s. Preveri dnevnik.")


def plot_results(csv_path, out, no_show=False):
    data = read_csv(csv_path)
    missing = set(SIGNALS) - set(data)
    if missing:
        raise RuntimeError(f"V CSV manjkajo stolpci: {sorted(missing)}")
    t = data["time"]
    config = csv_path.parent / "nastavitve.json"
    meta = json.loads(config.read_text(encoding="utf-8")) if config.is_file() else {}
    end = meta.get("requested_stop", float(t[-1]))
    plt.rcParams.update({"font.size": 11, "axes.grid": True, "grid.alpha": 0.25, "lines.linewidth": 1.5})
    blue, red = "#2166ac", "#b2182b"
    def finish(fig, axes, name):
        for ax in np.atleast_1d(axes).flat:
            ax.set_xlim(0, end); ax.set_xlabel("Čas [s]"); ax.legend(loc="best", fontsize=9)
        if meta.get("partial", False):
            fig.suptitle(f"Delni rezultati do {t[-1]:.3f} s", fontsize=10)
        fig.tight_layout(); fig.savefig(out / (name + ".png"), dpi=220); fig.savefig(out / (name + ".pdf"))
    fig, ax = plt.subplots(figsize=(10, 5))
    for node in [1041, 1042, 4012, 4062]:ax.plot(t, data[f"U{node}"], label=str(node))
    ax.set_ylabel("Napetost [p.u.]"); finish(fig, ax, "01_napetosti")
    fig, ax = plt.subplots(figsize=(11, 5)); ax.plot(t, data["U1041"], color=blue, label="1041 – native Dynawo")
    
    edges = [0, 30, 64, 80, 130, 140, end]
    for i, (left, right) in enumerate(zip(edges, edges[1:]), 1):
        right = min(right, end)
        if left < right:
            ax.axvspan(left, right, color=blue, alpha=0.04 if i % 2 else 0.1)
            ax.text((left + right)/2, 0.96, str(i), transform=ax.get_xaxis_transform(), ha="center", va="top")
    ax.set_ylabel("Napetost [p.u.]"); finish(fig, ax, "02_U1041_obmocja_analize")
    fig, ax = plt.subplots(figsize=(10, 5))
    for i in range(1, 6):ax.step(t, data[f"m{i}"], where="post", label=f"{i}_{1040+i}")
    ax.set_ylabel("Prestavno razmerje m [p.u.]"); finish(fig, ax, "03_oltc_prestavna_razmerja")
    fig, axes = plt.subplots(2, 1, figsize=(10, 7), sharex=True)
    axes[0].step(t, data["m1"], where="post", color=blue, label="Prestavno razmerje 1_1041")
    axes[0].set_ylabel("Prestavno razmerje [p.u.]")
    axes[1].plot(t, data["Uload1"], color=blue, label="Bremenska napetost B01")
    axes[1].set_ylabel("Napetost [p.u.]"); finish(fig, axes, "04_oltc_1_1041_in_breme")
    fig, axes = plt.subplots(2, 1, figsize=(10, 7), sharex=True)
    axes[0].plot(t, data["IrG12"], color=blue, label="Vzbujalni tok G12")
    axes[0].plot(t, data["IrLimitG12"], color=red, ls="--", label="Meja vzbujalnega toka G12")
    axes[0].set_ylabel("Vzbujalni tok [p.u.]")
    axes[1].step(t, data["OelG12"], where="post", color=blue, label="Časovni pogoj OEL G12")
    axes[1].set_yticks([0, 1], ["Ne", "Da"]); axes[1].set_ylim(-0.1, 1.15)
    finish(fig, axes, "05_G12_vzbujalni_tok_in_OEL")
    fig, ax = plt.subplots(figsize=(11, 5))
    for g in GENERATORS:ax.plot(t, data[f"IrG{g}"], label=f"G{g}")
    ax.set_ylabel("Vzbujalni tok [p.u.]"); finish(fig, ax, "06_vzbujalni_tokovi")
    fig, ax = plt.subplots(figsize=(10, 5))
    for g in [6, 7]:ax.plot(t, data[f"UtG{g}"], label=f"G{g}")
    ax.set_ylabel("Napetost na sponkah [p.u.]"); finish(fig, ax, "07_generatorski_napetosti")
    fig, ax = plt.subplots(figsize=(10, 5))
    for g in [6, 7, 17]:ax.plot(t, data[f"dwG{g}"], label=f"G{g}")
    ax.set_ylabel("Odstopanje kotne hitrosti [p.u.]"); finish(fig, ax, "08_odstopanja_kotnih_hitrosti")
    print("Grafi shranjeni:", out)
    if no_show:plt.close("all")
    else:plt.show()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--dynawo", help="Mapa namestitve simulatorja, ki vsebuje bin/dynawo.exe in ddb")
    parser.add_argument("--output", type=Path, default=BASE / "rezultati_nordic_dynawo")
    parser.add_argument("--csv", type=Path)
    parser.add_argument("--stop", type=float, default=166.8)
    parser.add_argument("--solver", choices=["ida", "sim"], default="ida")
    parser.add_argument("--step", type=float, default=0.01, help="Največji korak IDA, ne fiksni korak")
    parser.add_argument("--tolerance", type=float, default=0.005, help="Absolutna in relativna toleranca IDA")
    parser.add_argument("--no-show", action="store_true")
    mode = parser.add_mutually_exclusive_group()
    mode.add_argument("--simulate-only", action="store_true"); mode.add_argument("--plot-only", action="store_true")
    args = parser.parse_args()
    if not np.isfinite([args.stop,args.step,args.tolerance]).all() or min(args.stop,args.step,args.tolerance)<=0:parser.error("Čas, korak in toleranca morajo biti pozitivni")
    if args.csv and not args.plot_only:parser.error("--csv zahteva --plot-only")
    out = args.output.resolve(); out.mkdir(parents=True, exist_ok=True)
    if not args.plot_only:simulate(args, out)
    if not args.simulate_only:
        csv_path = args.csv.resolve() if args.csv else out / "nordic_dynawo.csv"
        if args.plot_only and not args.csv and not csv_path.is_file():
            csv_path = BASE / "referencni_rezultati" / "nordic_dynawo.csv"
            print("Izris priloženega CSV; nova simulacija ni bila izvedena.")
        plot_results(csv_path, out, args.no_show)


if __name__ == "__main__":main()
