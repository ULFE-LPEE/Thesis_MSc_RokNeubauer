from pathlib import Path
import argparse
import os
import subprocess
import csv
import json
import numpy as np
import matplotlib.pyplot as plt

BASE = Path(__file__).resolve().parent
MODEL_FILE = BASE / "Verbic_model_nestabilen.mo"
MODEL_NAME = "Verbic_model_nestabilen_1"
OPENIPSL = Path("C:/Users/rokne/Desktop/OpenIPSL-master/OpenIPSL/package.mo")
STOP_TIME = 197.5
OUTPUT_INTERVAL = 0.05


def simulate_with_spaces(mod, result_file):
    build_dir = Path(mod.tempdir)
    executable = build_dir / (MODEL_NAME + (".exe" if os.name == "nt" else ""))
    if not executable.is_file():
        raise RuntimeError(f"Prevajanje ni ustvarilo simulatorja: {executable}")
    override_file = build_dir / "python_simulation_override.txt"
    options = dict(mod.overridevariables)
    options.update(mod.simoptionsoverride)
    override_file.write_text("".join(f"{key}={value}\n" for key, value in options.items()),
                             encoding="utf-8")
    result_file = result_file.resolve()

    if result_file.exists():
        result_file.unlink()
    env = os.environ.copy()
    if os.name == "nt":
        omhome = Path(env["OPENMODELICAHOME"])
        dll_dirs = [omhome / "bin", omhome / "lib/omc", omhome / "lib/omc/cpp",
                    omhome / "lib/omc/omsicpp"]
        env["PATH"] = os.pathsep.join(map(str, dll_dirs)) + os.pathsep + env.get("PATH", "")
    command = [str(executable.resolve()), f"-overrideFile={override_file.resolve()}",
               f"-r={result_file}"]
    completed = subprocess.run(command, cwd=build_dir, env=env, capture_output=True,
                               text=True, errors="replace")
    log = (completed.stdout or "") + "\n" + (completed.stderr or "")
    (result_file.parent / "simulacija.log").write_text(log, encoding="utf-8")
    print(log, flush=True)
    if not result_file.is_file() or result_file.stat().st_size == 0:
        raise RuntimeError("Simulacija ni ustvarila rezultatov. Podrobnosti: "
                           + str(result_file.parent / "simulacija.log"))
    mod.solver_returncode = completed.returncode
    if completed.returncode != 0:
        print("Solver se je ustavil z napako; shranjujem razpolozljive rezultate. Glej simulacija.log.")
    mod.resultfile = result_file.as_posix()
    mod.simulationFlag = True


def simulate(args, out):
    from OMPython import ModelicaSystem
    for path in [args.model, args.openipsl]:
        if not path.is_file():
            raise FileNotFoundError(f"Datoteka ne obstaja: {path}")
    if os.name == "nt" and not os.environ.get("OPENMODELICAHOME"):
        installations = sorted(Path("C:/Program Files").glob("OpenModelica*"))
        if installations:
            os.environ["OPENMODELICAHOME"] = str(installations[-1])
    build = out / "build"
    build.mkdir(parents=True, exist_ok=True)
    print("Prevajanje nestabilnega modela ...", flush=True)
    mod = ModelicaSystem(args.model.resolve().as_posix(), MODEL_NAME,
                        [args.openipsl.resolve().as_posix()], customBuildDirectory=str(build))
    mod.setSimulationOptions(["startTime=0", f"stopTime={STOP_TIME}",
                              f"stepSize={OUTPUT_INTERVAL}", "tolerance=1e-8", "solver=dassl"])
    print("Zagon simulacije ...", flush=True)
    simulate_with_spaces(mod, out / "smib_nestabilen_res.mat")
    names = ["time", "N4.v", "N3.v", "gen.Qgen", "ultc.m"]
    available = mod.getSolutions()
    if available is None or set(names) - set(available):
        raise RuntimeError(f"Manjkajo rezultati {names}. Preveri simulacija.log.")
    values = np.asarray(mod.getSolutions(names), dtype=float)
    if values.ndim != 2 or values.shape[0] != len(names) or values.shape[1] < 2:
        raise RuntimeError("Ni dovolj podatkov za izris.")
    if not np.all(np.isfinite(values)):
        raise RuntimeError("Rezultati vsebujejo neveljavne vrednosti; preveri simulacija.log.")
    
    np.savetxt(out / "smib_nestabilen.csv", values.T, delimiter=";",
               header=";".join(names), comments="", fmt="%.12g")
    parameters = mod.getParameters()
    metadata = {"requested_stop_time": STOP_TIME, "last_time": float(values[0, -1]),
                "t_line": float(parameters["breaker.t_o"]),
                "t_oel": float(parameters["gen.tOEL"]),
                "solver_returncode": mod.solver_returncode,
                "model_name": MODEL_NAME, "model_file": str(args.model.resolve())}
    (out / "nastavitve.json").write_text(json.dumps(metadata, indent=2), encoding="utf-8")
    print("CSV shranjen:", out / "smib_nestabilen.csv", flush=True)
    if values[0, -1] < STOP_TIME - OUTPUT_INTERVAL:
        print(f"Simulacija se je končala pri {values[0,-1]:.3f} s namesto pri {STOP_TIME:g} s.")
        print("Predčasna ustavitev solverja sama po sebi ni dokaz fizikalne nestabilnosti.")


def plot_results(out, no_show=False):
    csv_path = out / "smib_nestabilen.csv"
    metadata_path = out / "nastavitve.json"
    if not csv_path.is_file() or not metadata_path.is_file():
        raise FileNotFoundError("Najprej zaženi simulacijo z --simulate-only.")
    with csv_path.open(encoding="utf-8-sig", newline="") as handle:
        reader = csv.reader(handle, delimiter=";")
        header = next(reader)
        values = np.asarray(list(reader), dtype=float).T
    data = dict(zip(header, values))
    t = data["time"]
    metadata = json.loads(metadata_path.read_text(encoding="utf-8"))
    plt.rcParams.update({"font.size": 11, "axes.grid": True,
                         "grid.alpha": 0.25, "lines.linewidth": 1.6})
    blue, red = "#2166ac", "#b2182b"

    def finish(fig, axes, filename):
        for ax in np.atleast_1d(axes).flat:
            ax.axvline(metadata["t_line"], color="#666666", ls=":", lw=1, label="Izpad voda")
            if metadata["t_oel"] <= t[-1]:
                ax.axvline(metadata["t_oel"], color=red, ls="--", lw=1, label="Aktivacija OEL")
            ax.set_xlim(t[0], t[-1])
            ax.set_xlabel("Čas [s]")
            ax.legend(loc="best", fontsize=9)
        if metadata["solver_returncode"] != 0 or t[-1] < metadata["requested_stop_time"] - OUTPUT_INTERVAL:
            fig.suptitle(f"Simulacija predčasno ustavljena pri {t[-1]:.3f} s", fontsize=10)
        fig.tight_layout()
        fig.savefig(out / (filename + ".png"), dpi=220)
        fig.savefig(out / (filename + ".pdf"))

    for signal, node, filename in [("N4.v", "N4", "01_Un4"), ("N3.v", "N3", "02_Un3")]:
        fig, ax = plt.subplots(figsize=(10, 4.5))
        ax.plot(t, data[signal], color=blue, label=f"Napetost {node} – OpenModelica")
        ax.set_ylabel("Napetost [p.u.]")
        finish(fig, ax, filename)
    fig, axes = plt.subplots(2, 1, figsize=(10, 7), sharex=True)
    axes[0].plot(t, data["gen.Qgen"], color=blue, label="Jalova moč generatorja")
    axes[0].set_ylabel("Qgen [p.u.]")
    axes[1].step(t, data["ultc.m"], where="post", color=blue, label="Prestavno razmerje m")
    axes[1].set_ylabel("Prestavno razmerje [p.u.]")
    finish(fig, axes, "03_Qgen_in_prestavno_razmerje")
    print("Grafi shranjeni:", out)
    if no_show:
        plt.close("all")
    else:
        plt.show()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--model", type=Path, default=MODEL_FILE)
    parser.add_argument("--openipsl", type=Path, default=OPENIPSL)
    parser.add_argument("--no-show", action="store_true")
    mode = parser.add_mutually_exclusive_group()
    mode.add_argument("--simulate-only", action="store_true")
    mode.add_argument("--plot-only", action="store_true")
    args = parser.parse_args()
    out = BASE / "rezultati_smib_nestabilen"
    if not args.plot_only:
        simulate(args, out)
    if not args.simulate_only:
        plot_results(out, args.no_show)


if __name__ == "__main__":
    main()

