from pathlib import Path
import argparse
import os
import subprocess
import numpy as np
import matplotlib.pyplot as plt
from OMPython import ModelicaSystem

BASE = Path(__file__).resolve().parent
MODEL_FILE = BASE / "Verbic_model_stabilen.mo"
MODEL_NAME = "Verbic_model_3_3"
OPENIPSL = Path("C:/Users/rokne/Desktop/OpenIPSL-master/OpenIPSL/package.mo")
STOP_TIME = 300.0
OUTPUT_INTERVAL = 0.05


def simulate_with_spaces(mod, result_file):
    build_dir = Path(mod.tempdir)
    executable = build_dir / (MODEL_NAME + (".exe" if os.name == "nt" else ""))
    if not executable.is_file():
        raise RuntimeError(f"Prevajanje ni ustvarilo simulatorja: {executable}")
    override_file = build_dir / "python_simulation_override.txt"
    options = dict(mod.overridevariables)
    options.update(mod.simoptionsoverride)
    override_file.write_text("".join(f"{key}={value}\n" for key, value in options.items()),
                             encoding="utf-8")
    result_file = result_file.resolve()
    
    if result_file.exists():
        result_file.unlink()
    env = os.environ.copy()
    if os.name == "nt":
        omhome = Path(env["OPENMODELICAHOME"])
        dll_dirs = [omhome / "bin", omhome / "lib/omc", omhome / "lib/omc/cpp",
                    omhome / "lib/omc/omsicpp"]
        env["PATH"] = os.pathsep.join(map(str, dll_dirs)) + os.pathsep + env.get("PATH", "")
    command = [str(executable.resolve()), f"-overrideFile={override_file.resolve()}",
               f"-r={result_file}"]
    completed = subprocess.run(command, cwd=build_dir, env=env, capture_output=True,
                               text=True, errors="replace")
    log = (completed.stdout or "") + "\n" + (completed.stderr or "")
    (result_file.parent / "simulacija.log").write_text(log, encoding="utf-8")
    print(log, flush=True)
    if completed.returncode != 0 or not result_file.is_file() or result_file.stat().st_size == 0:
        raise RuntimeError("Simulacija ni ustvarila rezultatov. Podrobnosti: "
                           + str(result_file.parent / "simulacija.log"))
    mod.resultfile = result_file.as_posix()
    mod.simulationFlag = True


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--model", type=Path, default=MODEL_FILE)
    parser.add_argument("--openipsl", type=Path, default=OPENIPSL)
    parser.add_argument("--no-show", action="store_true")
    args = parser.parse_args()
    for path in (args.model, args.openipsl):
        if not path.is_file():
            raise FileNotFoundError(f"Datoteka ne obstaja: {path}")
    
    if os.name == "nt" and not os.environ.get("OPENMODELICAHOME"):
        installations = sorted(Path("C:/Program Files").glob("OpenModelica*"))
        if installations:
            os.environ["OPENMODELICAHOME"] = str(installations[-1])
    out = BASE / "rezultati_smib_stabilen"
    build = out / "build"
    build.mkdir(parents=True, exist_ok=True)
    print("Prevajanje modela:", args.model, flush=True)
    mod = ModelicaSystem(
        args.model.resolve().as_posix(), MODEL_NAME,
        [args.openipsl.resolve().as_posix()], customBuildDirectory=str(build),
    )
   
    mod.setSimulationOptions([
        "startTime=0", f"stopTime={STOP_TIME}",
        f"stepSize={OUTPUT_INTERVAL}", "tolerance=1e-8", "solver=dassl",
    ])
    print("Zagon simulacije ...", flush=True)
    simulate_with_spaces(mod, out / "smib_stabilen_res.mat")
    names = [
        "time", "N3.v", "N4.v", "ULTC_TR.m", "BREME.Veff",
        "BREME.Pload_MW", "BREME.Qload_Mvar", "GENERATOR.Qgen",
        "GENERATOR.Qmax_eff", "GENERATOR.OEL_active", "GENERATOR.atQmax",
    ]
    solution_names = mod.getSolutions()
    if solution_names is None:
        raise RuntimeError("Datoteke z rezultati ni mogoče prebrati; preveri simulacija.log.")
    available = set(solution_names)
    missing = set(names) - available
    if missing:
        raise RuntimeError(f"V rezultatih manjkajo signali: {sorted(missing)}")
    values = np.asarray(mod.getSolutions(names), dtype=float)
    if values.ndim != 2 or values.shape[0] != len(names):
        raise RuntimeError(f"Nepričakovana oblika rezultatov: {values.shape}")
    data = dict(zip(names, values))
    t = data["time"]
    if t.size < 2 or t[-1] < STOP_TIME - OUTPUT_INTERVAL:
        raise RuntimeError(f"Simulacija ni dosegla končnega časa; zadnji čas: {t[-1]}")
    if not np.all(np.isfinite(values)):
        raise RuntimeError("Rezultati vsebujejo neveljavne vrednosti.")
    params = mod.getParameters()
    t_line = float(params["breaker.t_o"])
    t_oel = float(params["GENERATOR.tOEL"])
    s_base = float(params["GENERATOR.S_b"])
    qgen = data["GENERATOR.Qgen"] * s_base
    qlim = data["GENERATOR.Qmax_eff"] * s_base
    np.savetxt(out / "smib_stabilen.csv", values.T, delimiter=";",
               header=";".join(names), comments="", fmt="%.10g")
    plt.rcParams.update({"font.size": 11, "axes.grid": True,
                         "grid.alpha": 0.25, "lines.linewidth": 1.6})
    blue, red, gray = "#2166ac", "#b2182b", "#666666"

    def finish(fig, axes, filename):
        for ax in np.atleast_1d(axes).flat:
            ax.axvline(t_line, color=gray, ls=":", lw=1, label="Izpad voda")
            ax.axvline(t_oel, color=red, ls="--", lw=1, label="Aktivacija OEL")
            ax.set_xlim(0, STOP_TIME)
            ax.set_xlabel("Čas [s]")
            ax.legend(loc="best", fontsize=9)
        fig.tight_layout()
        fig.savefig(out / f"{filename}.png", dpi=220)
        fig.savefig(out / f"{filename}.pdf")

    fig, axes = plt.subplots(2, 1, figsize=(10, 7), sharex=True)
    for ax, signal, label in zip(axes, ["N4.v", "N3.v"], ["N4", "N3"]):
        ax.plot(t, data[signal], color=blue, label=f"Napetost {label}")
        ax.set_ylabel("Napetost [p.u.]")
    finish(fig, axes, "01_napetosti")

    fig, axes = plt.subplots(2, 1, figsize=(10, 7), sharex=True)
    axes[0].plot(t, qgen, color=blue, label="Jalova moč generatorja")
    axes[0].plot(t, qlim, color=red, ls=":", label="Zgornja meja jalove moči")
    axes[0].set_ylabel("Jalova moč [MVAr]")
    axes[1].step(t, data["GENERATOR.OEL_active"], where="post", color=red, label="OEL aktiven")
    axes[1].step(t, data["GENERATOR.atQmax"], where="post", color=blue, ls=":", label="Zgornja meja dosežena")
    axes[1].set_yticks([0, 1], ["Ne", "Da"])
    axes[1].set_ylim(-0.1, 1.2)
    axes[1].set_ylabel("Stanje")
    finish(fig, axes, "02_generator_oel")

    fig, axes = plt.subplots(2, 1, figsize=(10, 7), sharex=True)
    axes[0].step(t, data["ULTC_TR.m"], where="post", color=blue, label="Prestavno razmerje m")
    axes[0].set_ylabel("Prestavno razmerje [p.u.]")
    axes[1].plot(t, data["N4.v"], color=blue, label="Napetost N4")
    axes[1].plot(t, data["BREME.Veff"], color=red, label="Efektivna napetost bremena")
    axes[1].set_ylabel("Napetost [p.u.]")
    finish(fig, axes, "03_oltc_in_efektivna_napetost")

    fig, axes = plt.subplots(2, 1, figsize=(10, 7), sharex=True)
    axes[0].plot(t, data["BREME.Pload_MW"], color=blue, label="Delovna moč bremena")
    axes[0].set_ylabel("Delovna moč [MW]")
    axes[1].plot(t, data["BREME.Qload_Mvar"], color=red, label="Jalova moč bremena")
    axes[1].set_ylabel("Jalova moč [MVAr]")
    finish(fig, axes, "04_obnova_porabe")

    tail = t >= STOP_TIME - 30
    summary = [f"Končni čas: {t[-1]:.3f} s", f"Izpad voda: {t_line:g} s",
               f"Aktivacija OEL (časovno določena v modelu): {t_oel:g} s"]
    for signal in ["N3.v", "N4.v", "ULTC_TR.m", "BREME.Pload_MW", "BREME.Qload_Mvar"]:
        summary.append(f"{signal}: končna vrednost = {data[signal][-1]:.6f}; "
                       f"razpon zadnjih 30 s = {np.ptp(data[signal][tail]):.6g}")
    summary.append(f"Končna jalova moč generatorja: {qgen[-1]:.6f} MVAr")
    summary.append("Efektivna napetost bremena je v tem modelu Veff = N4.v / m.")
    text = "\n".join(summary)
    (out / "povzetek.txt").write_text(text, encoding="utf-8")
    print(text)
    print("Rezultati in grafi:", out)
    if args.no_show:
        plt.close("all")
    else:
        plt.show()


if __name__ == "__main__":
    main()
