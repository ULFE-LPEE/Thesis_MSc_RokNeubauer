model Verbic_model_nestabilen_1
   OpenIPSL.Electrical.Sources.SourceBehindImpedance.VoltageSources.VSource vSource(P_0 = 0, Q_0 = 0, v_0 = 1.04) annotation(
    Placement(transformation(origin = {-426, 15}, extent = {{-32, -32}, {32, 32}})));
  inner OpenIPSL.Electrical.SystemBase SysData annotation(
    Placement(transformation(origin = {-166, 276}, extent = {{-205, -79}, {205, 79}})));
  OpenIPSL.Electrical.Branches.PwLine v13(B = 0, G = 0, R = 0.02, X = 0.45, displayPF = true) annotation(
    Placement(transformation(origin = {-129, 81}, extent = {{-35, -35}, {35, 35}})));
  OpenIPSL.Electrical.Branches.PwLine v13_(B = 0, G = 0, R = 0.02, X = 0.45, displayPF = true) annotation(
    Placement(transformation(origin = {-93, -58}, extent = {{-35, -35}, {35, 35}})));
  OpenIPSL.Electrical.Buses.Bus N1(displayPF = false) annotation(
    Placement(transformation(origin = {-273, 16}, extent = {{-38, -38}, {38, 38}})));
  OpenIPSL.Electrical.Buses.Bus N3(displayPF = false) annotation(
    Placement(transformation(origin = {40, 13}, extent = {{-38, -38}, {38, 38}})));
  OpenIPSL.Electrical.Buses.Bus N4(V_b = 15e3, displayPF = true) annotation(
    Placement(transformation(origin = {343, 12}, extent = {{-38, -38}, {38, 38}})));
  OpenIPSL.Electrical.Events.Breaker breaker(t_o = 1) annotation(
    Placement(transformation(origin = {-172, -57}, extent = {{-18, -18}, {18, 18}})));

  model GEN

    outer OpenIPSL.Electrical.SystemBase SysData;
    OpenIPSL.Interfaces.PwPin_p p annotation(
      Placement(transformation(extent = {{-110, -10}, {-90, 10}})));
    parameter Real S_b = 100.0 "System base power [MVA]";
    parameter Real Pgen_MW = 0.0 "Active power generation [MW]";
    parameter Real Vref = 1.0 "Voltage reference [pu]";
    parameter Real Kq = 10.0 "Voltage control gain";
    parameter Real Tq = 2.0 "Reactive power time constant [s]";
    // Pred delovanjem omejevalnika naj generator lahko pomaga.
    parameter Real Qmax_pre = 1.30 "Maximum Q before OEL [pu]";
    // Po delovanju omejevalnika zmanjšamo razpoložljivo jalovo moč.
    parameter Real Qmax_post = 0.3 "Maximum Q after OEL [pu]";
    parameter Real Qmin = -0.30 "Minimum reactive power injection [pu]";
    // Čas aktivacije poenostavljenega omejevalnika vzbujanja.
    parameter Real tOEL = 65.0 "OEL activation time [s]";
    Real V "Terminal voltage magnitude [pu]";
    Real Pgen "Active power injection [pu]";
    Real Qcmd "Commanded reactive power [pu]";
    Real Qstate(start = 0.0, fixed = true) "Internal reactive power state [pu]";
    Real Qgen "Actual limited reactive power injection [pu]";
    Real Qmax_eff "Effective Q limit [pu]";
    Boolean atQmax "True if upper Q limit is active";
    Boolean atQmin "True if lower Q limit is active";
    Boolean OEL_active "True if OEL is active";
  protected
    Real V2;
  equation
    V = sqrt(p.vr^2 + p.vi^2);
    V2 = max(p.vr^2 + p.vi^2, 0.2^2);
    Pgen = Pgen_MW/S_b;
    Qcmd = Kq*(Vref - V);
    OEL_active = time >= tOEL;
    Qmax_eff = if time < tOEL then Qmax_pre else Qmax_post;
  // Anti-windup:
  // Če je stanje že na zgornji meji in regulator zahteva še več Q,
  // ga ne pustimo več rasti v neskončnost.
    der(Qstate) = if noEvent(Qstate >= Qmax_eff and Qcmd > Qmax_eff) then 0 elseif noEvent(Qstate <= Qmin and Qcmd < Qmin) then 0 else (Qcmd - Qstate)/Tq;
    Qgen = min(Qmax_eff, max(Qmin, Qstate));
    atQmax = Qgen >= Qmax_eff - 1e-6;
    atQmin = Qgen <= Qmin + 1e-6;
  // Generator injicira moč v omrežje.
  // Zato je tok v komponento negativen glede na porabniško konvencijo.
    p.ir = -(Pgen*p.vr + Qgen*p.vi)/V2;
    p.ii = -(Pgen*p.vi - Qgen*p.vr)/V2;
    annotation(
      Icon(graphics = {Rectangle(extent = {{-80, 60}, {80, -60}}, lineColor = {0, 0, 255}), Text(extent = {{-80, -70}, {80, -95}}, textString = "%name")}));
  
  end GEN;

  model ULTC
    outer OpenIPSL.Electrical.SystemBase SysData;
    OpenIPSL.Interfaces.PwPin_p p annotation(
      Placement(transformation(extent = {{-110, -10}, {-90, 10}})));
    OpenIPSL.Interfaces.PwPin_n n annotation(
      Placement(transformation(extent = {{90, -10}, {110, 10}})));
    parameter Real rT = 0.01 "Transformer resistance [pu on system base]";
    parameter Real xT = 0.10 "Transformer reactance [pu on system base]";
    parameter Real m0 = 1.00 "Initial tap ratio";
    parameter Real m_min = 0.85 "Minimum tap ratio";
    parameter Real m_max = 1.10 "Maximum tap ratio";
    parameter Real dm = 0.00625 "Tap step";
    parameter Real v_ref = 1.00 "Controlled voltage reference [pu]";
    parameter Real H = 0.01 "Deadband [pu]";
    parameter Real Tdelay = 10.0 "Delay before first tap action [s]";
    parameter Real Ttap = 5.0 "Tap change interval [s]";
    discrete Real m(start = m0, fixed = true) "Actual tap ratio";
    Real v_ctrl "Controlled secondary voltage magnitude [pu]";
  protected
    Real g;
    Real b;
    Real dp_re;
    Real dp_im;
    Real dn_re;
    Real dn_im;
  algorithm
    when initial() then
      m := m0;
    elsewhen sample(Tdelay, Ttap) then
  // Če je sekundarna napetost prenizka, zmanjšamo m.
  // Pri tej definiciji transformatorja manjši m dvigne napetost na n-strani.
      if v_ctrl < v_ref - H and pre(m) > m_min + dm/2 then
        m := max(m_min, pre(m) - dm);
  // Če je sekundarna napetost previsoka, povečamo m.
      elseif v_ctrl > v_ref + H and pre(m) < m_max - dm/2 then
        m := min(m_max, pre(m) + dm);
      else
        m := pre(m);
      end if;
    end when;
  equation
    v_ctrl = sqrt(n.vr^2 + n.vi^2);
  // Admitanca transformatorja y = 1 / (rT + j*xT) = g + j*b
    g = rT/(rT^2 + xT^2);
    b = -xT/(rT^2 + xT^2);
  // Model transformatorja s prestavnim razmerjem m na primarni strani:
  //
  // I_p = y * (V_p/m^2 - V_n/m)
  // I_n = y * (V_n - V_p/m)
  //
  // Pri praznem teku velja približno V_n = V_p / m.
  // Zato zmanjšanje m dvigne sekundarno napetost.
    dp_re = p.vr/(m*m) - n.vr/m;
    dp_im = p.vi/(m*m) - n.vi/m;
    dn_re = n.vr - p.vr/m;
    dn_im = n.vi - p.vi/m;
    p.ir = g*dp_re - b*dp_im;
    p.ii = b*dp_re + g*dp_im;
    n.ir = g*dn_re - b*dn_im;
    n.ii = b*dn_re + g*dn_im;
    annotation(
      Icon(graphics = {Ellipse(extent = {{-46, 30}, {8, -30}}, lineColor = {0, 0, 255}), Ellipse(extent = {{-10, 30}, {44, -30}}, lineColor = {0, 0, 255}), Line(points = {{100, 0}, {44, 0}}, color = {0, 0, 255}), Line(points = {{-100, 0}, {-46, 0}}, color = {0, 0, 255}), Text(extent = {{-38, 20}, {-4, -20}}, lineColor = {28, 108, 200}, textString = "1"), Text(extent = {{4, 18}, {32, -16}}, lineColor = {28, 108, 200}, textString = "2"), Text(extent = {{-100, 90}, {100, 40}}, lineColor = {0, 0, 255}, textString = "%name"), Text(extent = {{-80, -40}, {-20, -60}}, lineColor = {28, 108, 200}, textString = "ULTC"), Text(extent = {{10, -40}, {70, -60}}, lineColor = {28, 108, 200}, textString = "forced")}),
      Diagram(graphics = {Text(extent = {{-100, 140}, {100, 120}}, lineColor = {28, 108, 200}, textString = "vm = controlled bus voltage"), Text(extent = {{-100, 110}, {100, 95}}, lineColor = {28, 108, 200}, textString = "Forced mode: normal -> hold -> reverse")}));

  end ULTC;

  model BREME
  
  
    outer OpenIPSL.Electrical.SystemBase SysData;
    OpenIPSL.Interfaces.PwPin_p p annotation(
      Placement(transformation(extent = {{-110, -10}, {-90, 10}})));
  
    input Real m_tap "ULTC tap ratio";
  
    parameter Real P0_MW = 70.0 "Nominal active power [MW]";
    parameter Real Q0_Mvar = 40.0 "Nominal reactive power [Mvar]";
  
    parameter Real alpha = 1.5 "Transient active power voltage exponent";
    parameter Real beta = 2.5 "Transient reactive power voltage exponent";
  
    parameter Real V0 = 1.0 "Nominal voltage [pu]";
    parameter Real Vmin = 0.2 "Minimum voltage for numerical robustness [pu]";
    parameter Real S_b = 100.0 "System base power [MVA]";
  
    // Časovni konstanti dolgoročne obnove porabe
    parameter Real Tp_load = 80.0 "Active load restoration time constant [s]";
    parameter Real Tq_load = 60.0 "Reactive load restoration time constant [s]";
  
    // Omejitev, da obnova bremena numerično ne zraste neskončno visoko
    parameter Real Pmax_factor = 1.50 "Maximum active load factor relative to P0";
    parameter Real Qmax_factor = 1.50 "Maximum reactive load factor relative to Q0";
  
    Real V "Bus voltage magnitude [pu]";
    Real Veff "Effective restored load voltage [pu]";
    Real Vratio "Effective voltage ratio";
  
    Real Pvolt_MW "Instantaneous voltage-dependent active load [MW]";
    Real Qvolt_Mvar "Instantaneous voltage-dependent reactive load [Mvar]";
  
    Real xP_MW(start = 0.0, fixed = false) "Active load recovery state [MW]";
    Real xQ_Mvar(start = 0.0, fixed = false) "Reactive load recovery state [Mvar]";
  
    Real Praw_MW "Unbounded active load demand [MW]";
    Real Qraw_Mvar "Unbounded reactive load demand [Mvar]";
  
    Real Pload_MW "Actual active load [MW]";
    Real Qload_Mvar "Actual reactive load [Mvar]";
  
    Real Ppu "Actual active load [pu]";
    Real Qpu "Actual reactive load [pu]";
  
  protected
    Real V2;
    Real mtap_safe;
  
  initial equation
    // Začetno stanje nastavimo tako, da je začetna poraba približno P0/Q0.
    xP_MW = P0_MW - Pvolt_MW;
    xQ_Mvar = Q0_Mvar - Qvolt_Mvar;
  
  equation
    V = sqrt(p.vr^2 + p.vi^2);
    V2 = max(p.vr^2 + p.vi^2, Vmin^2);
  
    mtap_safe = max(m_tap, 0.2);
  
    // Ko ULTC zmanjšuje m, se efektivna napetost bremena obnavlja.
    Veff = max(V/mtap_safe, Vmin);
    Vratio = max(Veff/V0, Vmin);
  
    // Trenutni napetostno odvisni del bremena.
    // Ob padcu napetosti se ta del zmanjša.
    Pvolt_MW = P0_MW*Vratio^alpha;
    Qvolt_Mvar = Q0_Mvar*Vratio^beta;
  
    // Dolgoročna obnova bremena.
    // Če je dejanska poraba manjša od nazivne, xP/xQ postopoma rasteta.
    Praw_MW = Pvolt_MW + xP_MW;
    Qraw_Mvar = Qvolt_Mvar + xQ_Mvar;
  
    der(xP_MW) = (P0_MW - Praw_MW)/Tp_load;
    der(xQ_Mvar) = (Q0_Mvar - Qraw_Mvar)/Tq_load;
  
    // Numerična zaščita pred nerealno veliko obnovo.
    Pload_MW = noEvent(min(Pmax_factor*P0_MW, max(0.0, Praw_MW)));
    Qload_Mvar = noEvent(min(Qmax_factor*Q0_Mvar, max(0.0, Qraw_Mvar)));
  
    Ppu = Pload_MW/S_b;
    Qpu = Qload_Mvar/S_b;
  
    // Pozitiven Ppu in Qpu pomenita porabo iz omrežja.
    p.ir = (Ppu*p.vr + Qpu*p.vi)/V2;
    p.ii = (Ppu*p.vi - Qpu*p.vr)/V2;
  
    annotation(
      Icon(graphics = {
        Rectangle(extent = {{-80, 55}, {80, -55}}, lineColor = {0, 0, 255}),
        Text(extent = {{-70, 20}, {70, 0}}, textString = "Dynamic"),
        Text(extent = {{-70, 0}, {70, -20}}, textString = "load"),
        Text(extent = {{-80, -65}, {80, -90}}, textString = "%name")
      }));
  
  end BREME;

  GEN gen(Kq = 6, Tq = 0.6, Qmax_post = 0.3, tOEL = 85, Qstate(start = 0.3))  annotation(
    Placement(transformation(origin = {50, -198}, extent = {{-36, -36}, {36, 36}})));
  ULTC ultc(v_ref = 0.93, Tdelay = 15, Ttap = 10, xT = 0.1)  annotation(
    Placement(transformation(origin = {167, 11}, extent = {{-49, -49}, {49, 49}})));
  BREME breme  annotation(
    Placement(transformation(origin = {500, -60}, extent = {{-46, -46}, {46, 46}})));
equation
  connect(N1.p, v13.p) annotation(
    Line(points = {{-273, 16}, {-221, 16}, {-221, 80}, {-161, 80}}, color = {0, 0, 255}));
  connect(v13.n, N3.p) annotation(
    Line(points = {{-97.5, 81}, {14.5, 81}, {14.5, 13}, {40.5, 13}}, color = {0, 0, 255}));
  connect(v13_.n, N3.p) annotation(
    Line(points = {{-61.5, -58}, {15, -58}, {15, 12}, {41, 12}}, color = {0, 0, 255}));
  connect(v13_.p, breaker.r) annotation(
    Line(points = {{-124.5, -58}, {-154.5, -58}}, color = {0, 0, 255}));
  connect(breaker.s, N1.p) annotation(
    Line(points = {{-190, -57}, {-220, -57}, {-220, 17}, {-272, 17}}, color = {0, 0, 255}));
  connect(vSource.p, N1.p) annotation(
    Line(points = {{-390.8, 15}, {-332.8, 15}, {-332.8, 17}, {-272.8, 17}}, color = {0, 0, 255}));
  breme.m_tap = ultc.m;
  connect(N3.p, ultc.p) annotation(
    Line(points = {{40, 14}, {79, 14}, {79, 12}, {118, 12}}, color = {0, 0, 255}));
  connect(ultc.n, N4.p) annotation(
    Line(points = {{216, 12}, {344, 12}}, color = {0, 0, 255}));
  connect(N4.p, breme.p) annotation(
    Line(points = {{344, 12}, {454, 12}, {454, -60}}, color = {0, 0, 255}));
  connect(gen.p, N3.p) annotation(
    Line(points = {{14, -198}, {14, 14}, {40, 14}}, color = {0, 0, 255}));
  annotation(
    Diagram(coordinateSystem(extent = {{-800, -800}, {800, 800}})),
    Icon(coordinateSystem(extent = {{-800, -800}, {800, 800}})),
    version = "",
    uses);

end Verbic_model_nestabilen_1;
