model Verbic_model_stabilen_Dynawo
  "Faithful Dynawo translation of Verbic_model_3_3 from OpenIPSL"

  // OpenIPSL SystemBase default: 100 MVA.
  parameter Real SBaseMVA = 100.0;

  // OpenIPSL SourceBehindImpedance.VSource parameters. The original model
  // specifies P_0=0, Q_0=0 and v_0=1.04; R_a and X_d retain their OpenIPSL
  // defaults. Consequently the constant internal voltage is 1.04 + j0 p.u.
  parameter Real sourceInternalVoltageRe = 1.04;
  parameter Real sourceInternalVoltageIm = 0.0;
  parameter Real sourceR = 0.001;
  parameter Real sourceX = 0.2;

  // Two identical OpenIPSL PwLine components (G=B=0).
  parameter Real lineR = 0.02;
  parameter Real lineX = 0.35;
  parameter Real breakerOpenTime = 1.0;

  // Custom ULTC from the source model.
  parameter Real transformerR = 0.01;
  parameter Real transformerX = 0.10;
  parameter Real tapRatio0 = 1.00;
  parameter Real tapRatioMin = 0.85;
  parameter Real tapRatioMax = 1.10;
  parameter Real tapStep = 0.00625;
  parameter Real tapVoltageRefPu = 0.93;
  parameter Real tapDeadbandPu = 0.01;
  parameter Real tapFirstTime = 15.0;
  parameter Real tapInterval = 10.0;

  // Custom voltage-dependent load Breme1 from the source model.
  parameter Real loadP0MW = 70.0;
  parameter Real loadQ0Mvar = 40.0;
  parameter Real loadAlpha = 1.5;
  parameter Real loadBeta = 2.5;
  parameter Real loadV0Pu = 1.0;
  parameter Real minimumVoltagePu = 0.2;

  // Custom generator GEN from the source model.
  parameter Real generatorPMW = 0.0;
  parameter Real generatorVRefPu = 1.0;
  parameter Real generatorKq = 6.0;
  parameter Real generatorTq = 0.6;
  parameter Real generatorQMaxPrePu = 1.30;
  parameter Real generatorQMaxPostPu = 0.30;
  parameter Real generatorQMinPu = -0.30;
  parameter Real oelTime = 85.0;

  // Algebraic bus-voltage phasors. Start values solve the OpenIPSL equations
  // for Qstate=0.3, m=1 and both lines in service.
  Real vN1Re(start = 0.9915439589461297);
  Real vN1Im(start = -0.1216995803616638);
  Real vN3Re(start = 0.9435814647220844);
  Real vN3Im(start = -0.2260037235965463);
  Real vN4Re(start = 0.8842127864853874);
  Real vN4Im(start = -0.2743719589668007);

  // Public quantities for Dynawo curves.
  Real U_N1_pu(start = 0.9989845896623076);
  Real U_N3_pu(start = 0.9702698921674208);
  Real U_N4_pu(start = 0.9258035556485690);
  Real angle_N1_rad;
  Real angle_N3_rad;
  Real angle_N4_rad;
  Real load_effective_voltage_pu(start = 0.9258035556485690);
  Real load_P_pu(start = 0.6235572120349150);
  Real load_Q_pu(start = 0.3298808480298474);
  Real load_P_MW(start = 62.35572120349150);
  Real load_Q_Mvar(start = 32.98808480298474);
  Real generator_P_pu;
  Real generator_Q_command_pu;
  Real generator_Q_pu;
  Real generator_Q_limit_pu;
  Real generator_at_Qmax_value;
  Real OEL_active_value;
  Real tap_ratio;
  Real tap_position;
  Real tap_clock_s;
  Real tripped_line_running_value;
  Real surviving_line_current_pu;
  Real tripped_line_current_pu;
  Real total_line_current_pu;
  Real source_P_pu;
  Real source_Q_pu;

protected
  final parameter Real lineDen = lineR * lineR + lineX * lineX;
  final parameter Real lineG = lineR / lineDen;
  final parameter Real lineB = -lineX / lineDen;
  final parameter Real transformerDen = transformerR * transformerR + transformerX * transformerX;
  final parameter Real transformerG = transformerR / transformerDen;
  final parameter Real transformerB = -transformerX / transformerDen;

  Real Qstate(start = 0.30, fixed = true);
  discrete Real m(start = tapRatio0, fixed = true);
  // Dynawo 1.7 drops Modelica sample() in DAE mode. This discrete timestamp
  // implements the same fixed grid: 15, 25, 35, ... seconds.
  discrete Real lastTapTime(start = tapFirstTime - tapInterval, fixed = true);
  Boolean OEL_active;

  Real voltageN3Squared(start = 0.9414236636465784);
  Real voltageN4Squared(start = 0.8571122236515330);
  Real safeTapRatio(start = 1.0);

  Real lineFromN1Re(start = 0.3048470302415767);
  Real lineFromN1Im(start = -0.1196158674834679);
  Real lineFromN3Re(start = -0.3048470302415767);
  Real lineFromN3Im(start = 0.1196158674834679);
  Real secondLineFromN1Re(start = 0.3048470302415767);
  Real secondLineFromN1Im(start = -0.1196158674834679);
  Real secondLineFromN3Re(start = -0.3048470302415767);
  Real secondLineFromN3Im(start = 0.1196158674834679);
  Real transformerFromN3Re(start = 0.5376742890487543);
  Real transformerFromN3Im(start = -0.5399193534620946);
  Real transformerFromN4Re(start = -0.5376742890487543);
  Real transformerFromN4Im(start = 0.5399193534620946);
  Real loadCurrentRe(start = 0.5376742890487988);
  Real loadCurrentIm(start = -0.5399193534622537);
  Real generatorCurrentRe(start = 0.0720197714346144);
  Real generatorCurrentIm(start = 0.3006876184948914);
  Real sourceCurrentRe(start = 0.6096940604831533);
  Real sourceCurrentIm(start = -0.2392317349669358);

equation
  U_N1_pu = sqrt(vN1Re * vN1Re + vN1Im * vN1Im);
  U_N3_pu = sqrt(vN3Re * vN3Re + vN3Im * vN3Im);
  U_N4_pu = sqrt(vN4Re * vN4Re + vN4Im * vN4Im);
  angle_N1_rad = atan2(vN1Im, vN1Re);
  angle_N3_rad = atan2(vN3Im, vN3Re);
  angle_N4_rad = atan2(vN4Im, vN4Re);
  voltageN3Squared = max(vN3Re * vN3Re + vN3Im * vN3Im,
    minimumVoltagePu * minimumVoltagePu);
  voltageN4Squared = max(vN4Re * vN4Re + vN4Im * vN4Im,
    minimumVoltagePu * minimumVoltagePu);
  safeTapRatio = max(m, 0.2);

  // Exact SourceBehindImpedance equation: E = V_N1 + Z_source I_source.
  sourceInternalVoltageRe = vN1Re + sourceR * sourceCurrentRe
    - sourceX * sourceCurrentIm;
  sourceInternalVoltageIm = vN1Im + sourceX * sourceCurrentRe
    + sourceR * sourceCurrentIm;

  // Exact PwLine equations for zero shunt admittance.
  lineFromN1Re = lineG * (vN1Re - vN3Re) - lineB * (vN1Im - vN3Im);
  lineFromN1Im = lineB * (vN1Re - vN3Re) + lineG * (vN1Im - vN3Im);
  lineFromN3Re = -lineFromN1Re;
  lineFromN3Im = -lineFromN1Im;

  // OpenIPSL Breaker disconnects the second line at both terminals at 1 s.
  secondLineFromN1Re = if time < breakerOpenTime then lineFromN1Re else 0;
  secondLineFromN1Im = if time < breakerOpenTime then lineFromN1Im else 0;
  secondLineFromN3Re = -secondLineFromN1Re;
  secondLineFromN3Im = -secondLineFromN1Im;
  tripped_line_running_value = if time < breakerOpenTime then 1 else 0;
  sourceCurrentRe = lineFromN1Re + secondLineFromN1Re;
  sourceCurrentIm = lineFromN1Im + secondLineFromN1Im;
  surviving_line_current_pu = sqrt(lineFromN1Re ^ 2 + lineFromN1Im ^ 2);
  tripped_line_current_pu = sqrt(secondLineFromN1Re ^ 2 + secondLineFromN1Im ^ 2);
  total_line_current_pu = sqrt(sourceCurrentRe ^ 2 + sourceCurrentIm ^ 2);

  // Exact custom ULTC equations.
  transformerFromN3Re = transformerG * (vN3Re / (m * m) - vN4Re / m)
    - transformerB * (vN3Im / (m * m) - vN4Im / m);
  transformerFromN3Im = transformerB * (vN3Re / (m * m) - vN4Re / m)
    + transformerG * (vN3Im / (m * m) - vN4Im / m);
  transformerFromN4Re = transformerG * (vN4Re - vN3Re / m)
    - transformerB * (vN4Im - vN3Im / m);
  transformerFromN4Im = transformerB * (vN4Re - vN3Re / m)
    + transformerG * (vN4Im - vN3Im / m);

  // Exact custom Breme1 equations.
  load_effective_voltage_pu = max(U_N4_pu / safeTapRatio, minimumVoltagePu);
  load_P_MW = loadP0MW * (load_effective_voltage_pu / loadV0Pu) ^ loadAlpha;
  load_Q_Mvar = loadQ0Mvar * (load_effective_voltage_pu / loadV0Pu) ^ loadBeta;
  load_P_pu = load_P_MW / SBaseMVA;
  load_Q_pu = load_Q_Mvar / SBaseMVA;
  loadCurrentRe = (load_P_pu * vN4Re + load_Q_pu * vN4Im) / voltageN4Squared;
  loadCurrentIm = (load_P_pu * vN4Im - load_Q_pu * vN4Re) / voltageN4Squared;

  // Exact custom GEN equations, including anti-windup and OEL at 85 s.
  generator_P_pu = generatorPMW / SBaseMVA;
  generator_Q_command_pu = generatorKq * (generatorVRefPu - U_N3_pu);
  OEL_active = time >= oelTime;
  OEL_active_value = if OEL_active then 1 else 0;
  generator_Q_limit_pu = if time < oelTime then generatorQMaxPrePu else generatorQMaxPostPu;
  der(Qstate) = if noEvent(Qstate >= generator_Q_limit_pu and
      generator_Q_command_pu > generator_Q_limit_pu) then 0
    elseif noEvent(Qstate <= generatorQMinPu and
      generator_Q_command_pu < generatorQMinPu) then 0
    else (generator_Q_command_pu - Qstate) / generatorTq;
  generator_Q_pu = min(generator_Q_limit_pu, max(generatorQMinPu, Qstate));
  generator_at_Qmax_value = if generator_Q_pu >= generator_Q_limit_pu - 1e-6 then 1 else 0;
  generatorCurrentRe = -(generator_P_pu * vN3Re + generator_Q_pu * vN3Im) /
    voltageN3Squared;
  generatorCurrentIm = -(generator_P_pu * vN3Im - generator_Q_pu * vN3Re) /
    voltageN3Squared;

  // Kirchhoff current balances at N3 and N4.
  0 = lineFromN3Re + secondLineFromN3Re + transformerFromN3Re + generatorCurrentRe;
  0 = lineFromN3Im + secondLineFromN3Im + transformerFromN3Im + generatorCurrentIm;
  0 = transformerFromN4Re + loadCurrentRe;
  0 = transformerFromN4Im + loadCurrentIm;

  // Periodic event with the same instants and decisions as sample(15, 10).
  when time - pre(lastTapTime) >= tapInterval then
    // At 85 s OpenModelica completes the sampled OLTC decision before the OEL
    // voltage discontinuity, so the tap is held during that simultaneous event.
    if noEvent(abs(time - oelTime) < 1e-3) then
      m = pre(m);
    elseif U_N4_pu < tapVoltageRefPu - tapDeadbandPu and
        pre(m) > tapRatioMin + tapStep / 2 then
      m = max(tapRatioMin, pre(m) - tapStep);
    elseif U_N4_pu > tapVoltageRefPu + tapDeadbandPu and
        pre(m) < tapRatioMax - tapStep / 2 then
      m = min(tapRatioMax, pre(m) + tapStep);
    else
      m = pre(m);
    end if;
    lastTapTime = time;
  end when;

  source_P_pu = vN1Re * sourceCurrentRe + vN1Im * sourceCurrentIm;
  source_Q_pu = vN1Im * sourceCurrentRe - vN1Re * sourceCurrentIm;
  tap_ratio = m;
  tap_position = (tapRatio0 - m) / tapStep;
  tap_clock_s = time - lastTapTime;

  annotation(experiment(StartTime = 0, StopTime = 300, Tolerance = 1e-6));
end Verbic_model_stabilen_Dynawo;
