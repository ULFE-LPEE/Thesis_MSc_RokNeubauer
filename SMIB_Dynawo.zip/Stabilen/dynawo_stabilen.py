from pathlib import Path
import argparse
import csv
import json
import os
import re
import shutil
import subprocess
import sys
import uuid
import xml.etree.ElementTree as ET

import numpy as np
import matplotlib.pyplot as plt

BASE = Path(__file__).resolve().parent
PROJECT = BASE
OUTPUT = BASE / "rezultati_dynawo_stabilen"
PREFIX = "Verbic_model_stabilen"
NS = "http://www.rte-france.com/dynawo"


def model_parameters(project):
    text = (project / f"{PREFIX}_dynawo.mo").read_text(encoding="utf-8-sig")
    def value(name):
        match = re.search(r"parameter\s+Real\s+" + name + r"\s*=\s*([\d.eE+-]+)\s*;", text)
        if not match:
            raise ValueError(f"V modelu ni parametra {name}.")
        return float(match.group(1))
    return {"t_line": value("breakerOpenTime"), "t_oel": value("oelTime"),
            "s_base": value("SBaseMVA")}


def read_curves(path):
    with path.open(encoding="utf-8-sig", newline="") as handle:
        reader = csv.reader(handle, delimiter=";")
        header = next(reader)
        indices = [i for i, name in enumerate(header) if name.strip()]
        names = [header[i].strip() for i in indices]
        rows = [[float(row[i]) for i in indices] for row in reader if any(row)]
    values = np.asarray(rows, dtype=float)
    if values.ndim != 2 or len(values) < 2 or not np.all(np.isfinite(values)):
        raise RuntimeError(f"CSV ne vsebuje veljavnih časovnih potekov: {path}")
    result = dict(zip(names, values.T))
    if "time" not in result or np.any(np.diff(result["time"]) < 0):
        raise RuntimeError("CSV nima pravilne časovne osi.")
    return result


def find_dynawo(argument):
    config = BASE / "nastavitve_zagona.json"
    configured = json.loads(config.read_text(encoding="utf-8-sig")).get("dynawo_home", "") if config.is_file() else ""
    candidate = argument or os.environ.get("DYNAWO_HOME") or configured or shutil.which("dynawo.cmd")
    if not candidate:
        raise RuntimeError('Nastavi dynawo_home v nastavitve_zagona.json')
    path = Path(candidate).expanduser().resolve()
    if path.is_file():
        path = path.parent
    if not (path / "dynawo.cmd").is_file():
        raise FileNotFoundError(f"V navedeni namestitvi ni dynawo.cmd: {path}")
    return path


def simulate(project, out, dynawo_home):
    required = [f"{PREFIX}_dynawo.mo", f"{PREFIX}.jobs", f"{PREFIX}.dyd",
                f"{PREFIX}.par", f"{PREFIX}.crv", "run_dynawo.cmd",
                "python_compat/sitecustomize.py"]
    for name in required:
        if not (project / name).is_file():
            raise FileNotFoundError(project / name)

    run = out / "runs" / uuid.uuid4().hex[:12]
    run.mkdir(parents=True)
    for name in required:
        destination = run / name
        destination.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(project / name, destination)
    ET.register_namespace("", NS)
    tree = ET.parse(run / f"{PREFIX}.jobs")
    for directory in tree.findall(f".//{{{NS}}}modelicaModels/{{{NS}}}directory"):
        directory.set("path", run.resolve().as_posix())
    simulation = tree.find(f".//{{{NS}}}simulation")
    if simulation is None:
        raise RuntimeError("V jobs manjka element simulation.")
    requested_stop = float(simulation.attrib["stopTime"])
    tree.write(run / f"{PREFIX}.jobs", encoding="utf-8", xml_declaration=True)
    print("Zagon Dynawo. Prevajanje lahko traja nekaj časa.", flush=True)

    env = os.environ.copy()
    env["DYNAWO_HOME"] = str(dynawo_home)
    env["DYNAWO_PYTHON_COMMAND"] = sys.executable
    env["PYTHONPATH"] = str(run / "python_compat") + os.pathsep + env.get("PYTHONPATH", "")
    completed = subprocess.run(["cmd.exe", "/d", "/c", "run_dynawo.cmd"], env=env,
                               cwd=run, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                               text=True, errors="replace")
    log = completed.stdout or ""
    (run / "python_zagon.log").write_text(log, encoding="utf-8")
    print(log, flush=True)
    if completed.returncode != 0:
        raise RuntimeError(f"Dynawo se je končal s kodo {completed.returncode}. Dnevnik: {run / 'python_zagon.log'}")
    source = run / "outputs/curves/curves.csv"
    data = read_curves(source)
    if data["time"][-1] < requested_stop - 1e-4:
        raise RuntimeError(f"Simulacija je dosegla samo {data['time'][-1]:g} s. Rezultati: {source}")
    params = model_parameters(project)
    params.update({"stop_time": requested_stop, "project": str(project), "run": str(run)})
    shutil.copy2(source, out / "dynawo_stabilen.csv")
    (out / "nastavitve.json").write_text(json.dumps(params, indent=2), encoding="utf-8")
    print("CSV shranjen:", out / "dynawo_stabilen.csv", flush=True)


def plot_results(csv_path, out, params, no_show=False):
    raw = read_curves(csv_path)
    t = raw["time"]
    def signal(name):
        key = "VERBIC_VOLTAGE_STABILITY_system_" + name
        if key not in raw:
            raise KeyError(f"V CSV manjka signal {key}.")
        return raw[key]
    n4, n3 = signal("U_N4_pu"), signal("U_N3_pu")
    q = signal("generator_Q_pu")
    tap = signal("tap_ratio")
    plt.rcParams.update({"font.size": 11, "axes.grid": True, "grid.alpha": 0.25,
                         "lines.linewidth": 1.6})
    blue, red = "#2166ac", "#b2182b"
    def finish(fig, axes, name):
        for ax in np.atleast_1d(axes).flat:
            for time, label, color, style in [(params["t_line"], "Izpad voda", "#666666", ":"),
                                               (params["t_oel"], "Aktivacija OEL", red, "--")]:
                if t[0] <= time <= t[-1]:
                    ax.axvline(time, label=label, color=color, ls=style, lw=1)
            ax.set_xlim(t[0], t[-1])
            ax.set_xlabel("Čas [s]")
            ax.legend(loc="best", fontsize=9)
        fig.tight_layout()
        fig.savefig(out / (name + ".png"), dpi=220)
        fig.savefig(out / (name + ".pdf"))
    for voltage, node in [(n4, "N4"), (n3, "N3")]:
        fig, ax = plt.subplots(figsize=(10, 4.5))
        ax.plot(t, voltage, color=blue, label=f"Napetost {node} – Dynawo")
        ax.set_ylabel("Napetost [p.u.]")
        finish(fig, ax, "01_Un4" if node == "N4" else "02_Un3")
    fig, axes = plt.subplots(2, 1, figsize=(10, 7), sharex=True)
    axes[0].plot(t, q, color=blue, label="Jalova moč generatorja – Dynawo")
    axes[0].set_ylabel("Qgen [p.u.]")
    axes[1].step(t, tap, where="post", color=blue, label="Prestavno razmerje m")
    axes[1].set_ylabel("Prestavno razmerje [p.u.]")
    finish(fig, axes, "03_Qgen_in_prestavno_razmerje")
    fig, axes = plt.subplots(2, 1, figsize=(10, 7), sharex=True)
    axes[0].plot(t, signal("load_P_pu") * params["s_base"], color=blue, label="Delovna moč bremena")
    axes[0].set_ylabel("Delovna moč [MW]")
    axes[1].plot(t, signal("load_Q_pu") * params["s_base"], color=red, label="Jalova moč bremena")
    axes[1].set_ylabel("Jalova moč [MVAr]")
    finish(fig, axes, "04_obnova_porabe")
    summary = (f"CSV: {csv_path}\nKončni čas: {t[-1]:g} s\n"
               f"Končna napetost N4: {n4[-1]:.6f} p.u.\n"
               f"Končna napetost N3: {n3[-1]:.6f} p.u.\n"
               f"Končna jalova moč generatorja: {q[-1]:.6f} p.u.\n"
               f"Končno prestavno razmerje: {tap[-1]:.6f}\n")
    (out / "povzetek.txt").write_text(summary, encoding="utf-8")
    print(summary)
    print("Grafi:", out)
    if no_show:
        plt.close("all")
    else:
        plt.show()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--project", type=Path, default=PROJECT)
    parser.add_argument("--dynawo", help="Mapa namestitve Dynawo, ki vsebuje dynawo.cmd")
    parser.add_argument("--output", type=Path, default=OUTPUT)
    parser.add_argument("--csv", type=Path, help="Obstoječi Dynawo CSV; uporabi z --plot-only")
    parser.add_argument("--no-show", action="store_true")
    mode = parser.add_mutually_exclusive_group()
    mode.add_argument("--simulate-only", action="store_true")
    mode.add_argument("--plot-only", action="store_true")
    args = parser.parse_args()
    if args.csv and not args.plot_only:
        parser.error("--csv zahteva --plot-only")
    out = args.output.resolve()
    out.mkdir(parents=True, exist_ok=True)
    project = args.project.resolve()
    if not args.plot_only:
        simulate(project, out, find_dynawo(args.dynawo))
    if args.simulate_only:
        return
    source = args.csv.resolve() if args.csv else out / "dynawo_stabilen.csv"
    if not source.is_file() and args.plot_only and not args.csv:
        source = BASE / "referencni_rezultati" / "dynawo_stabilen.csv"
        print("Izris priloženih referenčnih rezultatov; nova simulacija ni bila izvedena.")
    settings = out / "nastavitve.json"
    params = (json.loads(settings.read_text(encoding="utf-8"))
              if settings.is_file() and not args.csv else model_parameters(project))
    plot_results(source, out, params, args.no_show)


if __name__ == "__main__":
    main()
