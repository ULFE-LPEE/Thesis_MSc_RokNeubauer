@echo off
setlocal
cd /d "%~dp0"
where cl.exe >nul 2>&1
if not errorlevel 1 goto compiler_ready
if defined VSDEVCMD if exist "%VSDEVCMD%" call "%VSDEVCMD%" -arch=x64 -host_arch=x64 >nul
where cl.exe >nul 2>&1
if not errorlevel 1 goto compiler_ready
if exist "%ProgramFiles(x86)%\Microsoft Visual Studio\Installer\vswhere.exe" (
  for /f "usebackq tokens=*" %%i in (`"%ProgramFiles(x86)%\Microsoft Visual Studio\Installer\vswhere.exe" -latest -products * -requires Microsoft.VisualStudio.Component.VC.Tools.x86.x64 -property installationPath`) do set "VS_INSTALL=%%i"
)
if defined VS_INSTALL call "%VS_INSTALL%\Common7\Tools\VsDevCmd.bat" -arch=x64 -host_arch=x64 >nul
where cl.exe >nul 2>&1
if errorlevel 1 (
  echo Napaka: manjka prevajalnik C++. Namesti Visual Studio Build Tools s C++ orodji.
  exit /b 2
)
:compiler_ready
if not defined DYNAWO_HOME (
  echo Napaka: zazeni prek python dynawo_nestabilen.py in nastavi pot Dynawo.
  exit /b 3
)
if not exist "%DYNAWO_HOME%\dynawo.cmd" exit /b 3
rem Dynawo 1.7 potrebuje pot do namestitve brez presledkov.
rem Uporabimo samo prost pogon in odstranimo samo svojo preslikavo.
set "DYNAWO_DRIVE="
for %%d in (W X Y Z V U T) do if not exist %%d:\ if not defined DYNAWO_DRIVE set "DYNAWO_DRIVE=%%d:"
if not defined DYNAWO_DRIVE (
  echo Napaka: ni prostega pogona za zacasno preslikavo.
  exit /b 4
)
subst %DYNAWO_DRIVE% "%DYNAWO_HOME%"
if errorlevel 1 exit /b 5
call %DYNAWO_DRIVE%\dynawo.cmd jobs "%~dp0Verbic_model_nestabilen.jobs"
set "DYNAWO_RESULT=%ERRORLEVEL%"
subst %DYNAWO_DRIVE% /d
exit /b %DYNAWO_RESULT%
