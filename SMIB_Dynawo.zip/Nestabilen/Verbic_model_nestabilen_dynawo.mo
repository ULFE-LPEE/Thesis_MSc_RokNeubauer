model Verbic_model_nestabilen_Dynawo
  "Faithful Dynawo translation of Verbic_model_nestabilen_1 from OpenIPSL"

  parameter Real SBaseMVA = 100.0;

  // OpenIPSL SourceBehindImpedance.VSource. R_a and X_d are the OpenIPSL
  // defaults retained by the source model.
  parameter Real sourceInternalVoltageRe = 1.04;
  parameter Real sourceInternalVoltageIm = 0.0;
  parameter Real sourceR = 0.001;
  parameter Real sourceX = 0.2;

  // Two identical parallel PwLine branches. The breaker opens one at 1 s.
  parameter Real lineR = 0.02;
  parameter Real lineX = 0.45;
  parameter Real breakerOpenTime = 1.0;

  // Custom ULTC parameters from the source model.
  parameter Real transformerR = 0.01;
  parameter Real transformerX = 0.10;
  parameter Real tapRatio0 = 1.00;
  parameter Real tapRatioMin = 0.85;
  parameter Real tapRatioMax = 1.10;
  parameter Real tapStep = 0.00625;
  parameter Real tapVoltageRefPu = 0.93;
  parameter Real tapDeadbandPu = 0.01;
  parameter Real tapFirstTime = 15.0;
  parameter Real tapInterval = 10.0;

  // Dynamic load BREME.
  parameter Real loadP0MW = 70.0;
  parameter Real loadQ0Mvar = 40.0;
  parameter Real loadAlpha = 1.5;
  parameter Real loadBeta = 2.5;
  parameter Real loadV0Pu = 1.0;
  parameter Real minimumVoltagePu = 0.2;
  parameter Real loadTp = 80.0;
  parameter Real loadTq = 60.0;
  parameter Real loadPMaxFactor = 1.50;
  parameter Real loadQMaxFactor = 1.50;

  // Custom generator GEN.
  parameter Real generatorPMW = 0.0;
  parameter Real generatorVRefPu = 1.0;
  parameter Real generatorKq = 6.0;
  parameter Real generatorTq = 0.6;
  parameter Real generatorQMaxPrePu = 1.30;
  parameter Real generatorQMaxPostPu = 0.30;
  parameter Real generatorQMinPu = -0.30;
  parameter Real oelTime = 85.0;

  // Initial phasors are the OpenModelica solution at t=0 with both lines
  // connected, Qstate=0.3 p.u., m=1 and P/Q load recovery states initialized.
  Real vN1Re(start = 0.9438031597146584);
  Real vN1Im(start = -0.1375009087126836);
  Real vN3Re(start = 0.8294589209654222);
  Real vN3Im(start = -0.2879513101938981);
  Real vN4Re(start = 0.7436489802829392);
  Real vN4Im(start = -0.3377318527972125);

  // Public quantities exported to Dynawo curves.
  Real U_N1_pu(start = 0.9537666927420914);
  Real U_N3_pu(start = 0.8780193953504131);
  Real U_N4_pu(start = 0.8167475805104618);
  Real angle_N1_rad;
  Real angle_N3_rad;
  Real angle_N4_rad;
  Real load_effective_voltage_pu(start = 0.8167475805104618);
  Real load_voltage_ratio(start = 0.8167475805104618);
  Real load_P_voltage_MW(start = 51.66897247400195);
  Real load_Q_voltage_Mvar(start = 24.11457614605872);
  Real load_xP_MW(start = 18.33102752599801);
  Real load_xQ_Mvar(start = 15.88542385394126);
  Real load_P_raw_MW(start = 70.0);
  Real load_Q_raw_Mvar(start = 40.0);
  Real load_P_MW(start = 70.0);
  Real load_Q_Mvar(start = 40.0);
  Real load_P_pu(start = 0.70);
  Real load_Q_pu(start = 0.40);
  Real generator_P_pu;
  Real generator_Q_command_pu;
  Real generator_Q_pu;
  Real generator_Q_limit_pu;
  Real generator_Q_state_pu;
  Real generator_at_Qmax_value;
  Real OEL_active_value;
  Real tap_ratio;
  Real tap_position;
  Real tap_clock_s;
  Real tripped_line_running_value;
  Real surviving_line_current_pu;
  Real tripped_line_current_pu;
  Real total_line_current_pu;
  Real source_P_pu;
  Real source_Q_pu;

protected
  final parameter Real lineDen = lineR * lineR + lineX * lineX;
  final parameter Real lineG = lineR / lineDen;
  final parameter Real lineB = -lineX / lineDen;
  final parameter Real transformerDen = transformerR * transformerR + transformerX * transformerX;
  final parameter Real transformerG = transformerR / transformerDen;
  final parameter Real transformerB = -transformerX / transformerDen;

  Real Qstate(start = 0.30, fixed = true);
  Real xP_MW(start = 18.33102752599801, fixed = true);
  Real xQ_Mvar(start = 15.88542385394126, fixed = true);
  discrete Real m(start = tapRatio0, fixed = true);
  // Dynawo 1.7 drops Modelica sample() in DAE mode. The timestamp implements
  // the source model's fixed OLTC grid: 15, 25, 35, ... seconds.
  discrete Real lastTapTime(start = tapFirstTime - tapInterval, fixed = true);
  Boolean OEL_active;

  Real voltageN3Squared(start = 0.7709180586115050);
  Real voltageN4Squared(start = 0.6670766102696933);
  Real safeTapRatio(start = 1.0);
  Real lineFromN1Re(start = 0.3449461086325203);
  Real lineFromN1Im(start = -0.2387673701701910);
  Real lineFromN3Re(start = -0.3449461086325203);
  Real lineFromN3Im(start = 0.2387673701701910);
  Real secondLineFromN1Re(start = 0.3449461086325203);
  Real secondLineFromN1Im(start = -0.2387673701701910);
  Real secondLineFromN3Re(start = -0.3449461086325203);
  Real secondLineFromN3Im(start = 0.2387673701701910);
  Real transformerFromN3Re(start = 0.5778369967481450);
  Real transformerFromN3Im(start = -0.8003157071500149);
  Real transformerFromN4Re(start = -0.5778369967481450);
  Real transformerFromN4Im(start = 0.8003157071500149);
  Real loadCurrentRe(start = 0.5778369967481450);
  Real loadCurrentIm(start = -0.8003157071500142);
  Real generatorCurrentRe(start = 0.1120552205168959);
  Real generatorCurrentIm(start = 0.3227809668096326);
  Real sourceCurrentRe(start = 0.6898922172651201);
  Real sourceCurrentIm(start = -0.4775347403403819);

equation
  U_N1_pu = sqrt(vN1Re * vN1Re + vN1Im * vN1Im);
  U_N3_pu = sqrt(vN3Re * vN3Re + vN3Im * vN3Im);
  U_N4_pu = sqrt(vN4Re * vN4Re + vN4Im * vN4Im);
  angle_N1_rad = atan2(vN1Im, vN1Re);
  angle_N3_rad = atan2(vN3Im, vN3Re);
  angle_N4_rad = atan2(vN4Im, vN4Re);
  voltageN3Squared = max(vN3Re * vN3Re + vN3Im * vN3Im,
    minimumVoltagePu * minimumVoltagePu);
  voltageN4Squared = max(vN4Re * vN4Re + vN4Im * vN4Im,
    minimumVoltagePu * minimumVoltagePu);
  safeTapRatio = max(m, 0.2);

  // OpenIPSL SourceBehindImpedance equation: E = V_N1 + Z_source I_source.
  sourceInternalVoltageRe = vN1Re + sourceR * sourceCurrentRe
    - sourceX * sourceCurrentIm;
  sourceInternalVoltageIm = vN1Im + sourceX * sourceCurrentRe
    + sourceR * sourceCurrentIm;

  // OpenIPSL PwLine equations for G=B=0.
  lineFromN1Re = lineG * (vN1Re - vN3Re) - lineB * (vN1Im - vN3Im);
  lineFromN1Im = lineB * (vN1Re - vN3Re) + lineG * (vN1Im - vN3Im);
  lineFromN3Re = -lineFromN1Re;
  lineFromN3Im = -lineFromN1Im;
  secondLineFromN1Re = if time < breakerOpenTime then lineFromN1Re else 0;
  secondLineFromN1Im = if time < breakerOpenTime then lineFromN1Im else 0;
  secondLineFromN3Re = -secondLineFromN1Re;
  secondLineFromN3Im = -secondLineFromN1Im;
  tripped_line_running_value = if time < breakerOpenTime then 1 else 0;
  sourceCurrentRe = lineFromN1Re + secondLineFromN1Re;
  sourceCurrentIm = lineFromN1Im + secondLineFromN1Im;
  surviving_line_current_pu = sqrt(lineFromN1Re ^ 2 + lineFromN1Im ^ 2);
  tripped_line_current_pu = sqrt(secondLineFromN1Re ^ 2 + secondLineFromN1Im ^ 2);
  total_line_current_pu = sqrt(sourceCurrentRe ^ 2 + sourceCurrentIm ^ 2);

  // Custom ULTC equations.
  transformerFromN3Re = transformerG * (vN3Re / (m * m) - vN4Re / m)
    - transformerB * (vN3Im / (m * m) - vN4Im / m);
  transformerFromN3Im = transformerB * (vN3Re / (m * m) - vN4Re / m)
    + transformerG * (vN3Im / (m * m) - vN4Im / m);
  transformerFromN4Re = transformerG * (vN4Re - vN3Re / m)
    - transformerB * (vN4Im - vN3Im / m);
  transformerFromN4Im = transformerB * (vN4Re - vN3Re / m)
    + transformerG * (vN4Im - vN3Im / m);

  // Dynamic BREME equations, including exponential voltage response,
  // long-term P/Q recovery and the source model's load caps.
  load_effective_voltage_pu = max(U_N4_pu / safeTapRatio, minimumVoltagePu);
  load_voltage_ratio = max(load_effective_voltage_pu / loadV0Pu, minimumVoltagePu);
  load_P_voltage_MW = loadP0MW * load_voltage_ratio ^ loadAlpha;
  load_Q_voltage_Mvar = loadQ0Mvar * load_voltage_ratio ^ loadBeta;
  load_P_raw_MW = load_P_voltage_MW + xP_MW;
  load_Q_raw_Mvar = load_Q_voltage_Mvar + xQ_Mvar;
  der(xP_MW) = (loadP0MW - load_P_raw_MW) / loadTp;
  der(xQ_Mvar) = (loadQ0Mvar - load_Q_raw_Mvar) / loadTq;
  load_P_MW = noEvent(min(loadPMaxFactor * loadP0MW, max(0, load_P_raw_MW)));
  load_Q_Mvar = noEvent(min(loadQMaxFactor * loadQ0Mvar, max(0, load_Q_raw_Mvar)));
  load_xP_MW = xP_MW;
  load_xQ_Mvar = xQ_Mvar;
  load_P_pu = load_P_MW / SBaseMVA;
  load_Q_pu = load_Q_Mvar / SBaseMVA;
  loadCurrentRe = (load_P_pu * vN4Re + load_Q_pu * vN4Im) / voltageN4Squared;
  loadCurrentIm = (load_P_pu * vN4Im - load_Q_pu * vN4Re) / voltageN4Squared;

  // Custom GEN equations with anti-windup and OEL at 85 s.
  generator_P_pu = generatorPMW / SBaseMVA;
  generator_Q_command_pu = generatorKq * (generatorVRefPu - U_N3_pu);
  OEL_active = time >= oelTime;
  OEL_active_value = if OEL_active then 1 else 0;
  generator_Q_limit_pu = if time < oelTime then generatorQMaxPrePu else generatorQMaxPostPu;
  der(Qstate) = if noEvent(Qstate >= generator_Q_limit_pu and
      generator_Q_command_pu > generator_Q_limit_pu) then 0
    elseif noEvent(Qstate <= generatorQMinPu and
      generator_Q_command_pu < generatorQMinPu) then 0
    else (generator_Q_command_pu - Qstate) / generatorTq;
  generator_Q_pu = min(generator_Q_limit_pu, max(generatorQMinPu, Qstate));
  generator_Q_state_pu = Qstate;
  generator_at_Qmax_value = if generator_Q_pu >= generator_Q_limit_pu - 1e-6 then 1 else 0;
  generatorCurrentRe = -(generator_P_pu * vN3Re + generator_Q_pu * vN3Im) /
    voltageN3Squared;
  generatorCurrentIm = -(generator_P_pu * vN3Im - generator_Q_pu * vN3Re) /
    voltageN3Squared;

  // Kirchhoff current balances at N3 and N4.
  0 = lineFromN3Re + secondLineFromN3Re + transformerFromN3Re + generatorCurrentRe;
  0 = lineFromN3Im + secondLineFromN3Im + transformerFromN3Im + generatorCurrentIm;
  0 = transformerFromN4Re + loadCurrentRe;
  0 = transformerFromN4Im + loadCurrentIm;

  // Same OLTC instants and voltage decisions as sample(15, 10).
  when time - pre(lastTapTime) >= tapInterval then
    if U_N4_pu < tapVoltageRefPu - tapDeadbandPu and
        pre(m) > tapRatioMin + tapStep / 2 then
      m = max(tapRatioMin, pre(m) - tapStep);
    elseif U_N4_pu > tapVoltageRefPu + tapDeadbandPu and
        pre(m) < tapRatioMax - tapStep / 2 then
      m = min(tapRatioMax, pre(m) + tapStep);
    else
      m = pre(m);
    end if;
    lastTapTime = time;
  end when;

  source_P_pu = vN1Re * sourceCurrentRe + vN1Im * sourceCurrentIm;
  source_Q_pu = vN1Im * sourceCurrentRe - vN1Re * sourceCurrentIm;
  tap_ratio = m;
  tap_position = (tapRatio0 - m) / tapStep;
  tap_clock_s = time - lastTapTime;

  annotation(experiment(StartTime = 0, StopTime = 200, Tolerance = 1e-6));
end Verbic_model_nestabilen_Dynawo;
