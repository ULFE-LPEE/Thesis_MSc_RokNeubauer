"""Compatibility shim for the Python scripts shipped with Dynawo 1.7.0.

Dynawo 1.7.0 occasionally sorts a dictionary containing the integer 0 and
equation indexes represented as strings. Python 3 does not compare integers
and strings directly. Keep normal sorting unchanged and only retry when all
values can be interpreted as integer indexes.
"""

import builtins


_original_sorted = builtins.sorted


def _dynawo_compatible_sorted(iterable, *args, **kwargs):
    items = list(iterable)
    try:
        return _original_sorted(items, *args, **kwargs)
    except TypeError:
        if args or "key" in kwargs:
            raise
        try:
            return _original_sorted(
                items,
                key=lambda value: int(value),
                reverse=kwargs.get("reverse", False),
            )
        except (TypeError, ValueError):
            raise


builtins.sorted = _dynawo_compatible_sorted
